#!/usr/bin/env python3
"""Tileset art as pixels: decode a metatile of a map's tileset pair.

Reads the decomp-layout files (tiles.4bpp, palettes/*.gbapal, metatiles.bin)
the build and the builder both provide, and answers what a metatile's lower
and upper layers draw, pixel by pixel.

    python voxel_art.py gTileset_General 16 18 24 26    prints drawn-pixel counts
"""

import os
import re
import struct
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
CELL = 16                 # a metatile edge, in pixels
PRIMARY_TILES = 640
PRIMARY_METATILES = 640
PRIMARY_PALETTES = 7
METATILE_ENTRIES = 12


def _incbins(filename, prefix):
    text = open(os.path.join(ROOT, "data", "tilesets", filename),
                encoding="utf-8").read()
    return dict(re.findall(rf"^({prefix}\w+)::[^\n]*\n\s*\.incbin\s+\"([^\"]+)\"", text, re.M))


with open(os.path.join(ROOT, "data", "tilesets", "headers.inc"), encoding="utf-8") as file:
    _HEADERS = dict(re.findall(r"^(gTileset_\w+)::(.*?)(?=^gTileset_\w+::|\Z)", file.read(), re.M | re.S))


def _tileset_paths(filename, prefix):
    paths = _incbins(filename, prefix)
    result = {}
    for symbol, header in _HEADERS.items():
        match = re.search(rf"\.4byte\s+({prefix}\w+)", header)
        if match and match[1] in paths:
            result[symbol] = os.path.join(ROOT, paths[match[1]])
    return result


METATILES = _tileset_paths("metatiles.inc", "gMetatiles_")
ATTRIBUTES = _tileset_paths("metatiles.inc", "gMetatileAttributes_")
GRAPHICS = _tileset_paths("graphics.inc", "gTilesetTiles_")
# Classic defines the general primary art in src/graphics.c, outside graphics.inc.
GRAPHICS.setdefault("gTileset_General",
                    os.path.join(ROOT, "data", "tilesets", "primary", "general", "tiles.4bpp.lz"))


def read_u16(path):
    raw = open(path, "rb").read()
    return list(struct.unpack("<%dH" % (len(raw) // 2), raw[:len(raw) // 2 * 2]))


def tileset_dir(symbol):
    path = GRAPHICS.get(symbol)
    return os.path.dirname(path) if path else None


class Graphics:
    """One tileset's 4bpp tiles and sixteen palettes, as RGB888."""

    def __init__(self, symbol):
        base = tileset_dir(symbol)
        self.tiles = b""
        self.palettes = []
        if base is None:
            return
        path = os.path.join(base, "tiles.4bpp")
        if os.path.exists(path):
            self.tiles = open(path, "rb").read()
        for i in range(16):
            pal = os.path.join(base, "palettes", "%02d.gbapal" % i)
            if not os.path.exists(pal):
                self.palettes.append(None)
                continue
            raw = open(pal, "rb").read()[:32]
            self.palettes.append([
                (((c) & 31) * 255 // 31, ((c >> 5) & 31) * 255 // 31,
                 ((c >> 10) & 31) * 255 // 31)
                for c in struct.unpack("<16H", raw)])


_GRAPHICS = {}


def graphics(symbol):
    """One Graphics per tileset per process: Pairs only read it."""
    if symbol not in _GRAPHICS:
        _GRAPHICS[symbol] = Graphics(symbol)
    return _GRAPHICS[symbol]


class Pair:
    """A primary/secondary tileset pair: what one map draws from."""

    def __init__(self, primary, secondary):
        self.gfx = (graphics(primary), graphics(secondary))
        self.meta = (read_u16(METATILES[primary]) if primary in METATILES else [],
                     read_u16(METATILES[secondary]) if secondary in METATILES else [])
        self.attr = (read_u16(ATTRIBUTES[primary]) if primary in ATTRIBUTES else [],
                     read_u16(ATTRIBUTES[secondary]) if secondary in ATTRIBUTES else [])
        self._layers = {}     # (metatile, layer) -> layer_pixels, asked again and again

    def entries(self, metatile):
        which = int(metatile >= PRIMARY_METATILES)
        index = metatile - which * PRIMARY_METATILES
        table = self.meta[which]
        start = index * METATILE_ENTRIES
        if start + METATILE_ENTRIES > len(table):
            return None
        return table[start:start + METATILE_ENTRIES]

    def attribute(self, metatile):
        which = int(metatile >= PRIMARY_METATILES)
        index = metatile - which * PRIMARY_METATILES
        table = self.attr[which]
        return table[index] if index < len(table) else 0

    def subtile(self, tile_id, palette_id):
        """8x8 as (rgb, index) pairs, row major, or None where unreadable.

        Tiles split at tile id 640, palettes independently at palette id 7,
        exactly as voxel_atlas.c LookupColor. A primary subtile can use a
        secondary palette (and vice versa).
        """
        which = int(tile_id >= PRIMARY_TILES)
        local = tile_id - which * PRIMARY_TILES
        gfx = self.gfx[which]
        base = local * 32
        if base + 32 > len(gfx.tiles):
            return None
        palettes = self.gfx[int(palette_id >= PRIMARY_PALETTES)].palettes
        pal = palettes[palette_id] if palette_id < len(palettes) else None
        if pal is None:
            return None
        out = []
        for y in range(8):
            for x in range(8):
                packed = gfx.tiles[base + y * 4 + x // 2]
                idx = (packed >> 4) if (x & 1) else (packed & 0xF)
                out.append((pal[idx], idx))
        return out

    def layer_pixels(self, metatile, layer):
        """Drawn pixels of one layer: {(x, y): rgb}. Index 0 is not drawn.

        Layer 0 is the metatile's base and layer 1 combines both of Classic's
        overlays, in drawing order. Index 0 is skipped on both, unlike the atlas,
        which floods layer 0's index 0 with
        the backdrop colour to get an opaque tile: here the question is what
        the artist DREW, and an index-0 pixel is where they drew nothing.
        """
        key = (metatile, layer)
        if key not in self._layers:
            self._layers[key] = self._layer_pixels(metatile, layer)
        return dict(self._layers[key])

    def _layer_pixels(self, metatile, layer):
        entries = self.entries(metatile)
        out = {}
        if entries is None:
            return out
        tiles = entries[:4] if layer == 0 else entries[4:]
        for index, entry in enumerate(tiles):
            quad = index % 4
            data = self.subtile(entry & 0x3FF, (entry >> 12) & 0xF)
            if data is None:
                continue
            flip_x, flip_y = bool(entry & 0x400), bool(entry & 0x800)
            ox, oy = (quad & 1) * 8, (quad >> 1) * 8
            for y in range(8):
                for x in range(8):
                    sx = 7 - x if flip_x else x
                    sy = 7 - y if flip_y else y
                    rgb, idx = data[sy * 8 + sx]
                    if idx == 0:
                        continue
                    out[(ox + x, oy + y)] = rgb
        return out


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    symbol = sys.argv[1]
    pair = Pair(symbol, symbol)
    for m in [int(v, 0) for v in sys.argv[2:]] or list(range(0, 64)):
        print("%-4d lower=%3d upper=%3d" % (m, len(pair.layer_pixels(m, 0)), len(pair.layer_pixels(m, 1))))


if __name__ == "__main__":
    main()
